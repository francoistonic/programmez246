# Programmez!-Ressources pour l'implémentation d'une solution IoT-Approche PaaS

Ce repository contient un certain nombre de resources pour l'implémentation d'une solution IoT (approche PaaS) décrite dans l'un des articles Programmez!.
Types des resources disponibles:
 - schémas JSON
 - exemples de données IoT
 - code sources

Liens articles:
TODO
