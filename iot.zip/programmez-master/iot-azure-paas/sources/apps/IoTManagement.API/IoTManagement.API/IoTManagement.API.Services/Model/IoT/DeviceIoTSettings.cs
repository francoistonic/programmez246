﻿namespace IoTManagement.API.Services.Model.IoT
{
    public class DeviceIoTSettings
    {
        public Twins Twins { get; set; }
    }
}
