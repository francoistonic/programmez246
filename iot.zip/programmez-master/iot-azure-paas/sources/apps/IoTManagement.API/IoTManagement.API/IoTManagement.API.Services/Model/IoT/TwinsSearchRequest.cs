﻿namespace IoTManagement.API.Services.Model.IoT
{
    public class TwinsSearchRequest
    {
        //string containing the 'where' condition
        public string WhereCondition { get; set; }
    }
}
