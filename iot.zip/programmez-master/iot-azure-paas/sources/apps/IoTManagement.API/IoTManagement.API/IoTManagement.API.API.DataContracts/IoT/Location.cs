﻿namespace IoTManagement.API.API.DataContracts.IoT
{
    public class Location
    {
        public string City { get; set; }

        public string Country { get; set; }
    }
}
