﻿namespace IoTManagement.API.API.DataContracts.IoT
{
    public class DeviceIoTSettings
    {
        public Twins Twins { get; set; }
    }
}
