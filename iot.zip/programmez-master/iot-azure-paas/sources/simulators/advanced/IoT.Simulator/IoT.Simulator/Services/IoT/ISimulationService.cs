﻿using System.Threading.Tasks;

namespace IoT.Simulator.Services
{
    interface ISimulationService
    {
        Task InitiateSimulationAsync();
    }
}
