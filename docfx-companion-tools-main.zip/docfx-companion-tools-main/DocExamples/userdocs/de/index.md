# Willkommen in der Dokumentation der Digital Manufacturing Platform

Dies ist die Hauptseite der Benutzerdokumentation in deutscher Sprache. Sie können zu Englisch [hier](../en/index.md).
