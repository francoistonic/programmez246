# Digital Manufacturing Platform

[![English](./.attachments/en.jpg) Documentation in English](./en/index.md)

[![Deutsch](./.attachments/de.png) Dokumentation in deutscher Sprache](./de/index.md)
