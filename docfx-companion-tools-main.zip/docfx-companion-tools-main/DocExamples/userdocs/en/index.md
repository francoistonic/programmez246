# Welcome to Digital Manufacturing Platform documentation

This is the main page of the user documentation in English. You can switch to German [here](../de/index.md).
