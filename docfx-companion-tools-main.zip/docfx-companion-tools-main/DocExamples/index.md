# Welcome in the documentation sample

This documentation sample is easy to use, on one side we've created a [developer documentation](./docs), on the other side an [end user documentation](./userdocs/index.md).

IF you are trying to click on the first link, the file does not exists yet. It will be created automatically by the TOC Generator tool. You only see in the sources main `toc.yml` file but no others for the sub directory. The same tool is used to create them magically!

It an use the `.order` file created and used by `Azure DevOps` to generate the TOC with a specific order. It can also uses advance features to find the main title in a markdown file, uses it as the name entry or just uses an override one for the folder names or file titles per directory. This feature is very useful when it comes to multi language automatically generated site and you want in the TOC to have a proper translated name.

## Examples of sub TOC generation

TODO: add screen capture of the resulting directory + toc screen captures.

## Example of override

TODO: add screen capture of the resulting directory + toc screen captures.
